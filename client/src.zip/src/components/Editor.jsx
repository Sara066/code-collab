import React, { useState, useEffect, useRef } from 'react';
import Editor from '@monaco-editor/react';
import * as Y from 'yjs';
import { WebsocketProvider } from 'y-websocket';
import { MonacoBinding } from 'y-monaco';
import { useAuth } from '../context/AuthContext';

const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:1234';
const CURSOR_COLORS = ['#f1c40f', '#e67e22', '#e74c3c', '#9b59b6', '#2ecc71', '#3498db', '#1abc9c'];

const CodeEditor = ({ roomId, language }) => {
  const { user, token } = useAuth();
  const [editorInstance, setEditorInstance] = useState(null);
  const [output, setOutput] = useState('');
  const [showConsole, setShowConsole] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState([]); // presence list, driven by awareness

  const providerRef = useRef(null);
  const typingTimeoutRef = useRef(null);

  useEffect(() => {
    if (!editorInstance || !roomId || !token) return;

    const ydoc = new Y.Doc();
    const provider = new WebsocketProvider(WS_URL, roomId, ydoc, {
      params: { token }
    });
    providerRef.current = provider;

    const yText = ydoc.getText('monaco');

    const myColor = CURSOR_COLORS[Math.floor(Math.random() * CURSOR_COLORS.length)];
    provider.awareness.setLocalStateField('user', {
      name: user?.username || 'Anonymous',
      color: myColor,
      typing: false
    });

    // Awareness "change" fires whenever ANY connected client's state updates —
    // including ours, joins, leaves, and typing status. This is the single
    // source of truth for the presence bar below.
    const updatePresenceList = () => {
      const states = Array.from(provider.awareness.getStates().entries());
      const users = states
        .filter(([, state]) => state.user)
        .map(([clientId, state]) => ({ clientId, ...state.user }));
      setOnlineUsers(users);
    };

    provider.awareness.on('change', updatePresenceList);
    updatePresenceList();

    provider.on('connection-error', () => {
      console.error('WebSocket connection rejected — check auth/room access');
    });

    const binding = new MonacoBinding(
      yText,
      editorInstance.getModel(),
      new Set([editorInstance]),
      provider.awareness
    );

    // Typing indicator: mark "typing" true only on the false->true transition
    // (not on every keystroke), clear it after 1.2s of no further changes.
    // Both awareness updates are deferred with setTimeout(0) so they run
    // AFTER Monaco finishes its own synchronous content-change handling —
    // calling setLocalStateField from directly inside onDidChangeModelContent
    // causes y-monaco's decoration re-render to re-enter Monaco's
    // deltaDecorations while it's still mid-call, which Monaco throws on.
    let isTyping = false;
    const contentListener = editorInstance.onDidChangeModelContent(() => {
      if (!isTyping) {
        isTyping = true;
        setTimeout(() => {
          provider.awareness.setLocalStateField('user', {
            name: user?.username || 'Anonymous',
            color: myColor,
            typing: true
          });
        }, 0);
      }

      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = setTimeout(() => {
        isTyping = false;
        provider.awareness.setLocalStateField('user', {
          name: user?.username || 'Anonymous',
          color: myColor,
          typing: false
        });
      }, 1200);
    });

    return () => {
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      contentListener.dispose();
      provider.awareness.off('change', updatePresenceList);
      binding.destroy();
      provider.disconnect();
      ydoc.destroy();
    };
  }, [editorInstance, roomId, token]);

  const handleEditorDidMount = (editor) => {
    setEditorInstance(editor);
  };

  const runCode = () => {
    if (!editorInstance) return;
    const code = editorInstance.getValue();
    setShowConsole(true);
    let logs = [];
    const mockConsole = {
      log: (...args) => logs.push(args.join(' ')),
      error: (...args) => logs.push('❌ ' + args.join(' '))
    };
    try {
      // NOTE: still runs in the main window context — fine while testing
      // solo, but needs to move into a sandboxed iframe before other users'
      // code can trigger this in a shared room. See multi-file work.
      new Function('console', code)(mockConsole);
      setOutput(logs.join('\n') || 'Executed successfully.');
    } catch (err) {
      setOutput('⚠️ ' + err.message);
    }
  };

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#1e1e1e' }}>
      <div style={{ padding: '8px 20px', background: '#2d2d2d', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <PresenceBar users={onlineUsers} />
        <button onClick={runCode} style={{ padding: '6px 16px', background: '#4caf50', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold' }}>
          ▶ Run JavaScript
        </button>
      </div>

      <div style={{ flex: 1, position: 'relative' }}>
        <Editor
          height="100%"
          language="javascript"
          theme="vs-dark"
          onMount={handleEditorDidMount}
          options={{ fontSize: 14, automaticLayout: true, minimap: { enabled: false } }}
        />
      </div>

      {showConsole && (
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: '35%', background: '#0a0a0a', borderTop: '2px solid #007acc', zIndex: 100 }}>
          <div style={{ padding: '5px 15px', background: '#252526', display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '11px', color: '#007acc', fontWeight: 'bold' }}>CONSOLE</span>
            <button onClick={() => setShowConsole(false)} style={{ background: 'none', border: 'none', color: '#888', cursor: 'pointer', fontSize: '18px' }}>×</button>
          </div>
          <pre style={{ margin: 0, padding: '15px', color: '#fff', fontSize: '13px', overflow: 'auto', whiteSpace: 'pre-wrap' }}>{output}</pre>
        </div>
      )}
    </div>
  );
};

// Small avatar row: initials bubble per online user, colored to match their
// cursor color, with a pulsing dot while they're actively typing.
const PresenceBar = ({ users }) => {
  if (users.length === 0) return <div />;

  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      {users.map((u, i) => (
        <div
          key={u.clientId}
          title={u.typing ? `${u.name} is typing…` : u.name}
          style={{
            width: '30px', height: '30px', borderRadius: '50%',
            background: u.color, color: '#111', display: 'flex',
            alignItems: 'center', justifyContent: 'center',
            fontSize: '12px', fontWeight: '700', border: '2px solid #2d2d2d',
            marginLeft: i === 0 ? 0 : '-8px', position: 'relative',
            boxShadow: u.typing ? `0 0 0 2px ${u.color}` : 'none',
            transition: 'box-shadow 0.2s'
          }}
        >
          {u.name?.slice(0, 2).toUpperCase() || '??'}
          {u.typing && (
            <span style={{
              position: 'absolute', bottom: '-2px', right: '-2px',
              width: '9px', height: '9px', borderRadius: '50%',
              background: '#4caf50', border: '2px solid #2d2d2d'
            }} />
          )}
        </div>
      ))}
      <span style={{ marginLeft: '16px', fontSize: '12px', color: '#888' }}>
        {users.length} online
      </span>
    </div>
  );
};

export default CodeEditor;


