const express = require('express');
const crypto = require('crypto');
const Room = require('../models/Room.model.cjs');
const { requireAuth } = require('../middleware/auth.middleware.cjs');

const router = express.Router();
router.use(requireAuth); // every route below requires a valid JWT

// Create a room — the creator becomes owner + first collaborator
router.post('/', async (req, res) => {
  try {
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: 'Room name is required' });

    // Unguessable, URL-safe id — this is what replaces the old free-typed roomId
    const roomId = crypto.randomBytes(9).toString('base64url');

    const room = await Room.create({
      roomId,
      name,
      owner: req.userId,
      collaborators: [req.userId]
    });

    res.status(201).json({ roomId: room.roomId, name: room.name });
  } catch (err) {
    console.error('Create room error:', err);
    res.status(500).json({ error: 'Something went wrong' });
  }
});

// List rooms the current user owns or collaborates on — powers the dashboard
router.get('/', async (req, res) => {
  try {
    const rooms = await Room.find({ collaborators: req.userId })
      .select('roomId name lastUpdated owner')
      .sort({ lastUpdated: -1 });
    res.json(rooms);
  } catch (err) {
    console.error('List rooms error:', err);
    res.status(500).json({ error: 'Something went wrong' });
  }
});

// Join a room via its invite id — adds the user as a collaborator.
// This is the ONLY way to gain access to a room; the WebSocket layer
// checks collaborator membership before allowing a connection at all.
router.post('/:roomId/join', async (req, res) => {
  try {
    const room = await Room.findOne({ roomId: req.params.roomId });
    if (!room) return res.status(404).json({ error: 'Room not found' });

    if (!room.collaborators.some(id => id.toString() === req.userId)) {
      room.collaborators.push(req.userId);
      await room.save();
    }

    res.json({ roomId: room.roomId, name: room.name });
  } catch (err) {
    console.error('Join room error:', err);
    res.status(500).json({ error: 'Something went wrong' });
  }
});

module.exports = router;
