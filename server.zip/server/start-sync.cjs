/*const WebSocket = require('ws');
const http = require('http');

const port = 1234;
const server = http.createServer((req, res) => {
  res.writeHead(200);
  res.end('Collaborative Server is Running');
});

const wss = new WebSocket.Server({ server });

const rooms = new Map();

wss.on('connection', (conn, req) => {
  const roomName = req.url.slice(1) || 'default';
  
  console.log(`✨ User joined room: ${roomName}`);

  if (!rooms.has(roomName)) {
    rooms.set(roomName, new Set());
  }
  rooms.get(roomName).add(conn);

  conn.on('message', (message) => {
    const clientsInRoom = rooms.get(roomName);
    if (clientsInRoom) {
      clientsInRoom.forEach((client) => {
        if (client !== conn && client.readyState === WebSocket.OPEN) {
          client.send(message);
        }
      });
    }
  });

  conn.on('close', () => {
    const clientsInRoom = rooms.get(roomName);
    if (clientsInRoom) {
      clientsInRoom.delete(conn);
      if (clientsInRoom.size === 0) {
        rooms.delete(roomName); 
      }
    }
    console.log(`❌ User left room: ${roomName}`);
  });
});

server.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
  console.log(`✅ Manual Room Isolation is ACTIVE.`);
});*/

/*
const WebSocket = require('ws');
const http = require('http');
const Y = require('yjs'); // 👈 Added Yjs

const port = 1234;
const server = http.createServer((req, res) => {
  res.writeHead(200);
  res.end('Collaborative Server is Running');
});

const wss = new WebSocket.Server({ server });
const rooms = new Map();

wss.on('connection', (conn, req) => {
  const roomName = req.url.slice(1) || 'default';
  console.log(`✨ User joined room: ${roomName}`);

  // Initialize room with a Yjs Doc if it doesn't exist
  if (!rooms.has(roomName)) {
    rooms.set(roomName, {
      doc: new Y.Doc(), // 👈 Master copy of the code
      conns: new Set()
    });
  }
  
  const room = rooms.get(roomName);
  room.conns.add(conn);

  // --- CRITICAL: Send current state to the new user ---
  const state = Y.encodeStateAsUpdate(room.doc);
  conn.send(state);

  conn.on('message', (message) => {
    try {
      // Update the master doc so the server "remembers" the code
      Y.applyUpdate(room.doc, new Uint8Array(message));

      // Broadcast to others
      room.conns.forEach((client) => {
        if (client !== conn && client.readyState === WebSocket.OPEN) {
          client.send(message);
        }
      });
    } catch (e) { /* Ignore non-yjs messages */// }
  //});

  /*conn.on('close', () => {
    room.conns.delete(conn);
    if (room.conns.size === 0) {
      rooms.delete(roomName); 
    }
    console.log(`❌ User left room: ${roomName}`);
  });
});

server.listen(port, () => {
  console.log(`🚀 Demo Server (WS + Yjs) running at http://localhost:${port}`);
}); */

// start-sync.cjs
// start-sync.cjs
/*const http = require('http');
const mongoose = require('mongoose');
const WebSocket = require('ws');
const Y = require('yjs');
const { setupWSConnection, docs } = require('y-websocket/bin/utils');
const Room = require('./room.cjs');

const port = 1234;

// --- MongoDB Setup ---
mongoose.connect('mongodb://127.0.0.1:27017/editorDB')
  .then(() => console.log("🍃 MongoDB Connected Successfully"))
  .catch(err => console.error("❌ Mongo Connection Error:", err));

// --- HTTP Server ---
const server = http.createServer((req, res) => {
  res.writeHead(200);
  res.end('y-websocket server running');
});

// --- WebSocket Server ---
const wss = new WebSocket.Server({ server });

// In-memory map: roomName -> persistence timer
const saveTimers = new Map();

wss.on('connection', async (conn, req) => {
  const roomName = decodeURIComponent(req.url.slice(1).split('?')[0]) || 'default';
  console.log(`✨ User joined: ${roomName}`);

  // 1. Let y-websocket handle ALL the sync protocol automatically
  setupWSConnection(conn, req, {
    docName: roomName,

    // 2. Called when the ydoc is first created for this room — rehydrate from DB
    gc: true,
  });

  // 3. After setup, grab the ydoc that y-websocket created and load DB state into it
  // We wait a tick so setupWSConnection can register the doc first
  setImmediate(async () => {
    const ydoc = docs.get(roomName);
    if (!ydoc) return;

    // Only rehydrate if the doc is empty (first connection to this room)
    const currentState = Y.encodeStateAsUpdate(ydoc);
    const isEmpty = currentState.length <= 2; // empty doc = just header bytes

    if (isEmpty) {
      try {
        const savedRoom = await Room.findOne({ roomName });
        if (savedRoom?.content) {
          Y.applyUpdate(ydoc, new Uint8Array(savedRoom.content));
          console.log(`📂 Rehydrated: ${roomName} from DB`);
        }
      } catch (err) {
        console.error("❌ DB Load Error:", err);
      }
    }

    // 4. Listen for updates and debounce-save to MongoDB
    ydoc.on('update', () => {
      // Debounce: only save after 1s of no edits (avoids hammering DB on every keystroke)
      if (saveTimers.has(roomName)) clearTimeout(saveTimers.get(roomName));

      saveTimers.set(roomName, setTimeout(async () => {
        try {
          const content = Buffer.from(Y.encodeStateAsUpdate(ydoc));
          await Room.findOneAndUpdate(
            { roomName },
            { content, lastUpdated: new Date() },
            { upsert: true }
          );
          console.log(`💾 Persisted: ${roomName}`);
        } catch (err) {
          console.error("❌ DB Save Error:", err);
        }
        saveTimers.delete(roomName);
      }, 1000));
    });
  });

  conn.on('close', () => {
    console.log(`👋 User left: ${roomName}`);
  });
});

server.listen(port, () => console.log(`🚀 Server running at http://localhost:${port}`));*/

require('dotenv').config();
const http = require('http');
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const WebSocket = require('ws');
const Y = require('yjs');
const { setupWSConnection, docs } = require('y-websocket/bin/utils');

const Room = require('./models/Room.model.cjs');
const { verifyToken } = require('./utils/jwt.util.cjs');
const authRoutes = require('./routes/auth.routes.cjs');
const roomRoutes = require('./routes/room.routes.cjs');

const PORT = process.env.PORT || 1234;

mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('🍃 MongoDB connected'))
  .catch(err => console.error('❌ Mongo connection error:', err));

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json());

app.get('/health', (req, res) => res.json({ status: 'ok' }));
app.use('/api/auth', authRoutes);
app.use('/api/rooms', roomRoutes);

const server = http.createServer(app);

// noServer: true — we handle the upgrade manually so we can check the JWT
// and room membership BEFORE the WebSocket connection is ever accepted.
const wss = new WebSocket.Server({ noServer: true });

const saveTimers = new Map();
const watchedRooms = new Set();

server.on('upgrade', async (req, socket, head) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const roomId = decodeURIComponent(url.pathname.slice(1));
    const token = url.searchParams.get('token');

    if (!token) {
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      return socket.destroy();
    }

    let decoded;
    try {
      decoded = verifyToken(token);
    } catch {
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      return socket.destroy();
    }

    const room = await Room.findOne({ roomId });
    const isCollaborator = room?.collaborators.some(id => id.toString() === decoded.userId);
    if (!room || !isCollaborator) {
      socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
      return socket.destroy();
    }

    req.userId = decoded.userId;
    req.roomId = roomId;

    wss.handleUpgrade(req, socket, head, (conn) => {
      wss.emit('connection', conn, req);
    });
  } catch (err) {
    console.error('Upgrade error:', err);
    socket.destroy();
  }
});

wss.on('connection', async (conn, req) => {
  const roomId = req.roomId;
  console.log(`✨ User ${req.userId} joined room: ${roomId}`);

  setupWSConnection(conn, req, { docName: roomId, gc: true });

  setImmediate(async () => {
    const ydoc = docs.get(roomId);
    if (!ydoc) return;

    if (!watchedRooms.has(roomId)) {
      const currentState = Y.encodeStateAsUpdate(ydoc);
      const isEmpty = currentState.length <= 2;

      if (isEmpty) {
        try {
          const savedRoom = await Room.findOne({ roomId });
          if (savedRoom?.content) {
            Y.applyUpdate(ydoc, new Uint8Array(savedRoom.content));
            console.log(`Rehydrated: ${roomId} from DB`);
          }
        } catch (err) {
          console.error('❌ DB Load Error:', err);
        }
      }

      watchedRooms.add(roomId);

      ydoc.on('update', () => {
        if (saveTimers.has(roomId)) clearTimeout(saveTimers.get(roomId));

        saveTimers.set(roomId, setTimeout(async () => {
          try {
            const content = Buffer.from(Y.encodeStateAsUpdate(ydoc));
            // No upsert here on purpose — a room must already exist (created via
            // the REST API) before its document content can be saved.
            await Room.findOneAndUpdate({ roomId }, { content, lastUpdated: new Date() });
            console.log(`Persisted: ${roomId}`);
          } catch (err) {
            console.error('❌ DB Save Error:', err);
          }
          saveTimers.delete(roomId);
        }, 1000));
      });
    }
  });

  conn.on('close', () => {
    console.log(`User ${req.userId} left room: ${roomId}`);
    setImmediate(() => {
      const ydoc = docs.get(roomId);
      if (!ydoc) {
        watchedRooms.delete(roomId);
        saveTimers.delete(roomId);
        console.log(`🧹 ${roomId} cleared from memory`);
      }
    });
  });
});

server.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));

//node start-sync.cjs